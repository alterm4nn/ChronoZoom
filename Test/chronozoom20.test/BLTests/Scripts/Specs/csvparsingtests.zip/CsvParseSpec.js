﻿/// <reference path="jquery-1.8.0.min.js" />
/// <reference path="csvUtils.js" />


describe("Parsed file", function () {

    //TestData
    var reader;
    var expectedx0 = "2500";
    var expectedx1 = "1980";
    var expectedy0 = "-5";
    var expectedy1 = "45.40";
    var incomingContent = "{\"thickness\":5, \"stroke\": \"#006aff\"}\r\n\r\nP,-D\r\n" + expectedx0 + "," + expectedy0 + "\r\n" + expectedx1 + "," + expectedy1;

    beforeEach(function () {
        reader = new CZ.CsvUtils.Reader();
    });

    it("should have values from Csv", function () {
        var json = reader.parseFile(incomingContent);

        expect(json.x.length).toEqual(2);
        expect(json.y.length).toEqual(2);
        expect(json.x[0]).toEqual(expectedx0);
        expect(json.x[1]).toEqual(expectedx1);
        expect(json.y[0]).toEqual(expectedy0);
        expect(json.y[1]).toEqual(expectedy1);
    });

    describe("when cvs contains empty values", function () {
        //TestData
        var errorText = "Invalid content of the file (record). ";
        var incomingContent1 = "{\"thickness\":5, \"stroke\": \"#006aff\"}\r\n\r\n\r\n,4\r\n1980,101";
        var errorPosition1 = "[55,1]";
        var data1 = [incomingContent1, errorPosition1];

        var incomingContent2 = "{\"thickness\":5, \"stroke\": \"#006aff\"}\r\n\r\n\r\n5,4\r\n,101";
        var errorPosition2 = "[52,1]";
        var data2 = [incomingContent2, errorPosition2];

        using("invalid cvs string", [data1, data2], function (value, value1) {
            it("should throw exeption", function () {
                expect(function () { reader.parseFile(value); }).toThrow(new Error(errorText + value1));
            });
        });
    });
});

//https://github.com/jphpsf/jasmine-data-provider
function using(name, values, func) {
    for (var i = 0, count = values.length; i < count; i++) {
        if (Object.prototype.toString.call(values[i]) !== '[object Array]') {
            values[i] = [values[i]];
        }
        func.apply(this, [values[i][0], values[i][1]]);
        jasmine.currentEnv_.currentSpec.description += ' (with "' + name + '" using ' + values[i][0].concat(' ') + ')';
    }
}